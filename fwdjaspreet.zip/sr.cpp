#include<iostream>
#include<cstdlib>
#include<math.h>

using namespace std;

//------------------------------------

class selective_repeat
      {
          int frames_in_window,sw,rw,total;
          int *frames,*sside, *rside;
          char* ack_recvd;

          public:

          selective_repeat()      //default constructor
                            {
                                frames = new int[100];  //total frames
                                sside = new int[16];
                                rside = new int[16];
                                ack_recvd = new char[16];
                            }
          void input();

          void sender_side();

          void receiver_side(int data);

          int get_total()
                            {
                              return total;
                            }

        };      //end of class

//--------------------------------------

void selective_repeat :: input()
        {
          int s;


          cout << "\nPlease enter number of bits for the sequence number: ";
          cin >> s;

          if(s>5)
                {
                  cout << "\nInvalid entry!!! Terminating";
                  exit(0);
                }

          total = pow(2,s);

          cout << "\nThe total possible frames: "<<total;

          cout << "\nThe number of frames to be sent at an instance are: "<< (total/2);

          frames_in_window = total/2;

          int z = 0;

          //-------------------------------

          for(int i=0;i<100;i++)
                  {
                    frames[i] = z;

                    z = (z+1)%total;
                  }

          //-------------------------------

          sw = frames_in_window;

          rw = sw;

          for(int i = 0;i<frames_in_window;i++)
                  {
                    sside[i] = frames[i];

                    rside[i] = frames[i];

                    ack_recvd[i] = 'n';
                  }
                  cout << "\nEnd of input";
          return;
        }           //end of input function

//--------------------------------

void selective_repeat :: sender_side()
        {
            cout << "\n\t\t---------  SENDER'S SIDE -------------";

            for(int i=0;i<frames_in_window;i++)
                    {
                      if(ack_recvd[i] == 'n')
                          cout << "\nSENDER: Frame number "<<sside[i]<<" has been sent successfully!!";
                    }
            return;
        }

//---------------------------------

void selective_repeat :: receiver_side(int total1)
        {
          cout << "\n\t\t---------  RECEIVER'S SIDE -------------";

          int random,j,counter=0;

          int ack_prob;

          for(int i=0;i<frames_in_window;i++)
                  {
                    if(ack_recvd[i]=='n')
                          {
                            random = rand()%10;

                            if(random!=5)
                                  //if equal to 5 then frame is not received due to some reasons
                            {     //!!!!!!!!!!
                              for(j=0;i<frames_in_window;j++)
                                    {
                                      if(rside[j]==sside[i])
                                            {
                                              cout << "\nRECEIVER: Received frame number "<<rside[j]<<" successfully!!";

                                              rside[j] = frames[rw];

                                              rw = (rw+1)%total1;
                                              break;
                                            }
                                    }
                              if(j == frames_in_window)
                                    cout << "\nRECEIVER: Duplicate Frame number "<<sside[i]<<" has been discarded!";

                                    ack_prob = rand()%5;
                                    //acknowledgement is lost if ack_prob == 3

                                    switch(ack_prob)
                                            {
                                              case 3:
                                                    cout << "\nAcknowledgment for frame "<<sside[i]<<" has been lost!";

                                                    cout << "\nSENDER: Resend the frame after timeout";

                                                    ack_recvd[i]='n';
                                                    break;
                                              default:
                                                    cout << "\nAcknowledgement for frame "<<sside[i]<<" has been received successfully!";
                                                    ack_recvd[i] = 'p';

                                            }


                            }//!!!!!!!!!!!!!!!!!!

                            else
                                  {
                                    int r1 = rand()%2;
                                    switch(r1)
                                              {
                                                case 0:
                                                      cout << "\nRECEIVER: Received frame number "<<sside[i]<<" is damaged!";
                                                      cout << "\nRECEIVER: The Acknowledgement sent "<<sside[i]<<" is NEGATIVE ";
                                                      break;
                                                default:
                                                      cout << "\nFrame "<<sside[i]<<" lost during transmission ";
                                                      cout << "\nSENDER: Resend the frame after timeout";
                                              }
                                    ack_recvd[i] = 'n';
                                  }
                                }
                              }
                  for(j=0;j<frames_in_window;j++)
                            {
                              if(ack_recvd[j]=='n')

                              break;
                            }
                  for(int k=j;k<frames_in_window;k++,counter++)
                            {
                              sside[counter]=sside[k];

                              if(ack_recvd[k]=='n')

                                    ack_recvd[counter]='n';
                              else

                                    ack_recvd[counter]='p';
                            }
                  if(counter!=frames_in_window)
                            {
                              for(int k=counter;k<frames_in_window;k++)
                                    {
                                      sside[k] = frames[sw];

                                      sw = (sw+1)%total1;

                                      ack_recvd[k]='n';
                                    }
                            }

                          return;
        }

//--------------------------------------

int main()
              { char choice;



                selective_repeat sr;

                sr.input();

                sr.sender_side();

                  do{
                int value = sr.get_total();

                sr.receiver_side(value);

                cout << "\nDo You Want to Continue? (y/n): ";

                cin >> choice;

              }while(choice=='y'||choice=='Y');

                return 0;
              }
//---------------------------------------END OF MAIN
