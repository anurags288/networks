
// Hamming code

#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;

int fn_power(int);
int main()
		{	char* bits = new char [100];
			cout << "\nPlease input the bits in your data:  ";
					int size=0;
					char bit;
					for(int i=0;i<100;i++)
						{	cout << "\nEnter the character ( enter a non-binary number to exit ): ";
							cin >> bit;
								if(bit!='0' && bit!='1')
								break;
							bits[i]=bit;
							size++;
						}
			int parity;
					cout << "\nPlease select the parity by entering the appropriate choice number: ";
					cout << "\n1. ODD Parity";
					cout << "\n2. EVEN Parity";
					cout << "\n CHOICE: ";
					cin >>parity;
					if(parity!=1 && parity!=2)
						{	cout << "\nInappropriate choice entered !!!! Terminating";
							return 0;
						}

			cout << "\nThe entered data is as follows:  "<<bits;
			int r=0;

			while(1)
					{	if( pow(2,r) >= size + r + 1 )
						break;

						r++;
					}
			char* codeword = new char [size+r];

			int counter = 0;
			int i = 1;
			int bits_count = 0;

			while(bits_count<size)
					{	if ( i == pow(2,counter) )
							{	codeword[i-1] = 'X';
								counter++;
							}
						else
							{	codeword[i-1] = bits[bits_count];
								bits_count++;
							}
						i++;
					}
			cout << "\nTemporary codeword: "<<codeword<<endl;
			//i = 0;
			int value,inpos;
			counter = 0;
			int* cb_count = new int [r];

			for(int k=0;k<r;k++)
				cb_count[k]=0;

			for(i=0;i<size+r;i++)
				{	if( codeword[i] == '1' )
						{	value = i+1;
							for ( int j = value-1;j>=0;j-- )
								{	if(codeword[j] == 'X')
										{
                      inpos=fn_power(j+1);
                      cb_count[inpos]++;
											value-= (j+1);     //pow(2,j);
											j=value;
										}
      //if ((value ==1) || (value ==2)) value+=1;  //to access first /second bit
								}
						}
				}

			cout<<"output is";
			for(int k=0;k<r;k++)
				cout << cb_count[k];

			i = 0;

				switch(parity)
							{	case 1:
									cout << "\nYou chose odd parity. ";
									while(i<r)
										{	if(cb_count[i]%2==0)
												codeword[(int)pow(2,i)-1]='1';
											else
												codeword[(int)pow(2,i)-1]='0';
											i++;
										}
									break;
								case 2:
									cout << "\nYou chose even parity. ";
									while(i<r)
										{	if(cb_count[i]%2==0)
												codeword[(int)pow(2,i)-1]='0';
											else
												codeword[(int)pow(2,i)-1]='1';
											i++;
										}
									break;
							}
				cout << "\nThe codeword comprising of the information bits and the check bits is as follows: "<<codeword;
				return 0;
		}






int fn_power(int x)
{
   int i=0;
   while (pow(2,i) < x)
      i++;
    return i;

}
