#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

bool check_bits ( char* data,int length );
int count_1_bits ( char* data, int length );

int main()
		{	/*int size;
			cout << "\nPlease input the the number of bits in the data to be entered:  ";
			cin >> size;*/

			char* bits = new char [ 100 ];
			//char* r_bits = new char [ size ];
			//char parity_bit,r_parity_bit;

			//do
				/*{*/	cout << "\nPlease input the bits in your data:  ";
					int size=0;
					char bit;
					for(int i=0;i<100;i++)
						{	cout << "\nEnter the character ( enter a non-binary number to exit ): ";
							cin >> bit;
								if(bit!='0' && bit!='1')
								break;
							bits[i]=bit;
							size++;
						}
						/*if ( strlen(bits) > size )
						cout << "\nThe number of bits in the data exceeds the expected number of bits. Please re-enter";
				}	while ( strlen(bits) != size );*/

			cout << "\nThe entered data is as follows:  "<<bits;

			bool status = check_bits ( bits,size );
			char* r_bits = new char [size+1];

			if ( status == 0 )
				{	
					cout << "\nInvalid data entered!! Hence terminating....... ";
					return 0;
				}

			int count = count_1_bits ( bits,size );
			int choice;

			cout << "\nPlease select one of the choices from the below given options:  ";
			cout << "\nCHOICE 1:  EVEN PARITY";
			cout << "\nCHOICE 2:  ODD PARITY";
			cout << "\n\nCHOICE NO:   ";
			cin >> choice;

			switch ( choice )
						{	case 1:
								cout << "\nYou chose even parity.";
								if ( count%2 == 0 )
									bits[size] = '0';
								else
									bits[size] = '1';
								break;
							case 2:
								cout << "\nYou chose odd parity.";
								if ( count%2 != 0 )	
									bits[size] = '0';
								else
									bits[size] = '1';
								break;
							default:
								cout << "\nInvalid choice !!! Terminating.....";
								return 0;
						}
			cout << "\nThe parity bit set according to the entered data is :  "<<bits[size]<<endl;
			//return 0;
			
			cout << "\nThe codeword generated is: "<<bits;//<<" "<<parity_bit;

			/*do
				{	cout << "\nPlease input the bits in the received data:  ";
					cin >> r_bits;
						if ( strlen(r_bits) > size+1 )
						cout << "\nThe number of bits in the data exceeds the expected number of bits. Please re-enter";
				}	while ( strlen(r_bits) != size+1 );*/

			srand((unsigned)time(0));
			int noe = rand()%(size+1);
			//cout << noe;

			int* error = new int [noe];

			for(int i=0;i<size+1;i++)
				r_bits[i] = bits[i];

			for(int i=0;i<size+1;i++)
				{	error[i] = rand()%(size+1);
					if (r_bits[error[i]]=='0')
						r_bits[error[i]]='1';
					else
						r_bits[error[i]]='0';
				}

			/*srand((unsigned)time(0));
			error[0] = rand()%(size+1);

			do	{
					error[1] = rand()%(size+1);
			  	}  while(error[1] == error[0]);
				
			if ( r_bits[error[0]]=='0' )
				r_bits[error[0]]='1';
			else
				r_bits[error[0]]='0';

			if ( r_bits[error[1]]=='0')
				r_bits[error[1]]='1';
			else
				r_bits[error[1]]='0';*/
			//cout << "\nPlease input the parity bit: ";
			//cin >> r_parity_bit;

			cout << "\nThe received codeword is: "<<r_bits;//<<r_parity_bit;

			bool r_status = check_bits ( r_bits,size );
		
			if ( r_status == 0 )
				{	
					cout << "\nInvalid data entered!! Hence terminating....... ";
					return 0;
				}

			int r_count = count_1_bits ( r_bits,size );
		
			char c_parity_bit;
		
			switch ( choice )
						{	case 1:
								cout << "\nYou chose even parity.";
								if ( r_count%2 == 0 )
									c_parity_bit = '0';
								else
									c_parity_bit = '1';
								break;
							case 2:
								cout << "\nYou chose odd parity.";
								if ( r_count%2 != 0 )	
									c_parity_bit = '0';
								else
									c_parity_bit = '1';
								break;
							default:
								cout << "\nInvalid choice !!! Terminating.....";
								return 0;
						}
			if ( c_parity_bit == r_bits[size] )
				cout << "\nData is not corrupted...\n";
			else
				cout << "\nData is corrupted...\n";

			return 0;
		}

bool check_bits(char* data, int length)
		{	int count =0;
				for ( int i=0;i<length;i++)
					{	if ( data[i]!='0' && data[i]!='1' )
						count++;
					}
			if ( count == 0 )
					return 1 ;
			else	
					return 0;
		}

int count_1_bits ( char* data, int length )
		{	int count = 0;
				for ( int i=0;i<length;i++)
					{	if ( data[i] == '1' )
							count++;
					}
			return count;
		}						

						
