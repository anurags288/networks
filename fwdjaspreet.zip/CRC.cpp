#include<iostream>
#include<cstdlib>
#include<string>

using namespace std;

class CRC
          {
              public:

              int input_value();
              long XOR( long x1, long x2 );
              long divide( long divisor, long dividend );
              int count( long n );
              void display ( int *a );
              long random( long n );

          };  //end of class

//------------------- FUNCTION DEFINITIONS -----------------

int CRC :: input_value()
        {
          int data , temp;

          cout << "\nEnter the data in binary form: ";
          cin >> data;

          temp = data;

          if(temp < 0)
              return 0;

          //else check for validity

          while(temp > 0)
                {
                  if( temp%10 > 1)
                    return 0;
                  temp/=10;
                }
          return data;

        }     //-----------------------------------------

long CRC :: XOR ( long x1, long x2 )
          {
            string a = "";
            string b = "";
            long result;  //to store the retrieved result

            while( n1!=0 && n2!=0 )
                  {
                    int x = (int)(x1%10);
                    int y = (int)(x2%10);

                    if((x==0 && y==1) || (x==1 && y==0))
                        b="1";
                    else
                        b="0";

                    a = b + a;
                    n1/=10;
                    n2/=10;
                  }
            // convert string to long for storing in Division
            //-----------------------------------------------
            return result;
          }
