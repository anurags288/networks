import java.io.*;
import java.util.Random;

//-------------------

class crc
{
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

//-----------------------------------------------

    int accept_data()throws IOException         //in-class definition
    {
        int info;
        try
        {
            info = Integer.parseInt(in.readLine());
            int x = info;
            if(x < 0)
                return 0;

            //Binary Check

            while(x>0)
            {
                if(x%10 > 1)
                    return 0;
                x = x/10;
            }

        }
        catch(NumberFormatException e)
        {
            return 0;
        }

        return info;
    }

//---------------------------------------------------


    long XOR(long n1,long n2)             //in-class definition
    {
          String result = "";
          String x = "";
          while(n1!=0 && n2!=0)
          {
              int a = (int)(n1%10);
              int b = (int)(n2%10);

              if(((a == 0) && (b == 1)) || ((a == 1) && (b==0)))
              x = "1";
              else
              x = "0";

              result = x + result;
              n1 = n1/10;
              n2 = n2/10;
          }
          return (Long.parseLong(x));
    }

//------------------------------------------------------

int no_of_bits(long num)
{
    int c = 0;
    while(num>0)
    {
        c++;
        num = num/10;
    }
    return c;
}

//--------------------------------------------------

    long Division(long divisor,long dividend)
    {
           long temp = 0;
           while(no_of_bits(dividend) >= no_of_bits(divisor))
           {
                   temp = divisor* (int)Math.pow(10,(no_of_bits(dividend) - no_of_bits(divisor)));
                   dividend = XOR(temp,dividend);
           }

           return dividend;

    }

    //--------------------------------------------------



    void display_data(int Ar[])
    {
        for(int i = 0;i<Ar.length;i++)
        {
            System.out.print(Ar[i]);
        }

    }

    //---------------------------------------------------

    long generate_random_errors(long num)
    {
        int size = no_of_bits(num);
        int A[] = new int[size];
        //--------------
        for(int i = size-1;i>=0;i--,num=num/10)
            A[i] = (int)(num%10);
        //--------------

        Random rand = new Random();
        int times = rand.nextInt(3) + 1;
        int count = 0;

        //----------------

        while(count <= times)
        {
            int pos = rand.nextInt(size);
            if(A[pos] == 0)
                A[pos] = 1;
            else
                A[pos] = 0;
            ++count;
        }

//----------------------------

        for(int i = 0;i<size;i++)
            num = num*10+A[i];

        return num;
    }

//-----------------------------------------------------------------------

    public static void main(String args[])throws IOException
    {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        crc obj = new crc();
        System.out.print("PLEASE ENTER INFORMATION BITS: ");
        int x = obj.accept_data();
        while(x == 0)
        {
            System.out.println("You Have Entered Wrong Data, Please Try Again");
            x = obj.accept_data();
        }

        System.out.print("PLEASE ENTER THE GENERATING POLYNOMIAL: ");
        int gp = obj.accept_data();
        while(gp == 0)
        {
            System.out.print("You Have Entered Wrong Data, Please Try Again");
            gp = obj.accept_data();
        }


        int i = obj.no_of_bits(x);
        int gbit = obj.no_of_bits(gp);
        long output = x*(long)(Math.pow(10,gbit-1));
        long rem = obj.Division(gp,output);

        //---------------------------------------------------

        System.out.println("INFORMATION BITS 		 :"+x);
        System.out.println("GENERATING POLYNOMIAL 		 :"+gp);
        System.out.println("CODE WORD        :"+output);
        System.out.println("REMAINDER        :"+rem);
        //--------------------------------------------------
        long code = output + rem;
        System.out.println("FINAL CODEWORD      :"+code);
        //--------------------------------------------------
        long e = obj.generate_random_errors(output);
        System.out.println("RECEIVED CODEWORD 	 \t :" +e);
        rem = obj.Division(gp,e);
        //---------------------------------------------

        if(rem == 0)
        System.out.println("Received Word Is CORRECT !!!!!");
        else
        System.out.println("Received Word Is INCORRECT !!!!!");


    }

}
