#include<iostream>
using namespace std;

//---------------------------------------------------------------------------------------------------------------------------------------------

class Sender

	{	int wait ;
		int ack ; 

		public:

		void get_data();
		void send_data();
		//void trigger_wait();
		//int get_wait();
		//void reset_acknowledgement();
		//void acknowledgement_received();
		//void wait_over();
	
	};	//end of class

void Sender :: get_data()

{	cout << "\nData Ready for Transmission. ";
	return;
}

/*int Sender :: get_wait()

{	return wait;
}*/

void Sender :: send_data()

{	cout << "\nData sent to the Receiver. ";
	return;
}

/*void Sender :: trigger_wait()

{	wait = 1;	// 1 denotes that the sender is waiting for receiving acknowledgement
	return;
}

void Sender :: reset_acknowledgement()

{	ack = 0;	// ack is one only if sender receives acknowledgement from receiver
	cout << "\nAcknowledgement received by the Sender";
	return;
}

void Sender :: acknowledgement_received()

{	ack = 1;
	return;
}

void Sender :: wait_over()

{	wait = 0;
	return;
}*/

//---------------------------------------------------------------------------------------------------------------------------------------------

class Receiver

	{	int a;

		public:

		void receive_data();
		//void generating_acknowledgement();
		//void send_acknowledgement();
		void give_data_NL();
	};//end of class

void Receiver :: receive_data()

{	cout << "\nReceiver has received the data.";
	return;
}

/*void Receiver :: generating_acknowledgement()

{	a = 1;
	return;
}

void Receiver :: send_acknowledgement()

{	cout << "\nAcknowledgement sent by the receiver";
	return;
}*/

void Receiver :: give_data_NL()

{	cout << "\nData transferred to the Networking Layer";
	return;
}

//---------------------------------------------------------------------------------------------------------------------------------------------

int main()
		{	Sender s;
			Receiver r;

			cout << "\n-----------IMPLEMENTATION OF THE SIMPLEX PROTOCOL------------";
			cout << "\n\n\n\nAssuming that sender has 10 frames of data.";
			int i = 0;

			
			do
				{	
					cout << "\n-----------FRAME " << i+1 << " ----------------";
					
					s.get_data();
					s.send_data();
					//s.trigger_wait();
					
					r.receive_data();
					//r.generating_acknowledgement();
					//r.send_acknowledgement();
					r.give_data_NL();

					//s.acknowledgement_received();
					//s.reset_acknowledgement();
					//s.wait_over();
				
					cout << "\n------------------------------------------------\n";

					i++;
				
				}	while(i<=9);

			return 0 ;
		}

//---------------------------------------------------------------------------------------------------------------------------------------------
					


