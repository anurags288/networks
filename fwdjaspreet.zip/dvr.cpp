//---------------       DISTANCE VECTOR ROUTING       --------------------

#include<iostream>
#include<stdlib.h>
using namespace std;

class distance_vector_routing

{
    int total_routers,target_router,adjacent,adj;
    int x[10],y[10];

    int delay_table[10][2], router_table[20][2];

    public:
              void input();
              void calculate();
              void display_result();

};             //end of class

//--------------------------------

void distance_vector_routing :: input()
      {
            cout << "\nPlease enter the total number of routers in the network: ";
            cin >> total_routers;

            cout << "\nPlease enter the router number whose Routing Table is to be generated: ";
            cin >> target_router;

            if(target_router>total_routers)
                    {       cout << "\nInvalid!!!!!Terminating...";
                            exit(0);
                    }
            cout << "\nPlease enter the numbers of routers next to the target router: ";
            cin >> adjacent;

            //------------------

            for(int i=0;i<adjacent;i++)
            {
              cout << "\nThe router number of the adjacent router "<<i+1<<" is: ";
              cin >> adj;

              delay_table[i][0] = adj;
              cout << "\nPlease fill the routing table for router number "<<adj<<" below.";

              for(int j=0;j<total_routers;j++)
                        {
                          cout << "\n Distance from Router "<<j<<": ";
                          if(j==adj)
                                    {
                                      router_table[adj][j] = 0;
                                      cout << router_table[adj][j] << endl;
                                      continue;
                                    }
                          cin >> router_table[adj][j];
                        }
              cout << "\nPlease input the Delay units from target router "<<target_router<<" to this Router: ";
              cin >> delay_table[i][1];
            }
      }         //end of input

//------------------------------------

void distance_vector_routing :: calculate()
        {
          cout<<"!!!!!!";
          for(int i=0;i<total_routers;i++)
              {
                x[i]=-1;
                y[i]=-1;
              }

          for(int i=0;i<adjacent;i++)
              {
                x[delay_table[i][0]] = delay_table[i][1];
                y[delay_table[i][0]] = delay_table[i][0];
              }
          x[target_router] = 0;
          y[target_router] = target_router;

          for(int i=0;i<total_routers;i++)
              {
                if(x[i]==-1)
                        {
                          int minimum = 9999;
                          int min = 0;

                          for(int j=0;j<adjacent;j++)
                                  {
                                    if(minimum>router_table[delay_table[j][0]][i] + delay_table[j][1])
                                    //if minimum is greater than the distance between the adjacent and the node under consideration and the delay time from main node to the adjacent node
                                            {
                                              minimum = router_table[delay_table[j][0]][i] + delay_table[j][1];
                                              min = delay_table[j][0];
                                            }
                                  }
                          x[i] = minimum;
                          y[i] = min;
                        }
              }
        }         //end of calculate()

//-------------------------------------------

void distance_vector_routing :: display_result()
          {
            cout << "\nThe Routing Table created for Router number "<<target_router<<" is as follows.\n";
            cout << "ROUTER \t     DISTANCE";
		char m ;

            for(int i=0;i<total_routers;i++)
                    {	m = (i+65);
                      cout <<"\n      "<<m <<"."<< "\t"<<x[i]<<"\t";
                      if(y[i]==target_router)
                              cout << "--";
                      else
                              cout << (char)(y[i]+65);

                    }
          }           //end of displying

//-------------------------------------------

int main()
              {   char choice;
                  do{


                  distance_vector_routing dvr;
                  dvr.input();
                  dvr.calculate();
                  dvr.display_result();

                  cout << "\nDo you want to continue? (y/n): ";
                  cin >> choice;

                }while(choice=='y'||choice=='Y');

                return 0;

              }
